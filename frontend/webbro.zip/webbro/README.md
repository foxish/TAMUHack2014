WebCat
======

Chrome extension to leverage Chrome-Sync to introduce Pocket-like functionality

Features:

 - Categorize the web:
 - Better bookmarks
 - Ability to tag and search via tags
 - Chrome sync capable

Code is well categorized. In the JS folder, all the bookmark interactions occur within **bookmarks.class.js**.
The calls to it are made by **popup.js**.

Published in the Chrome Webstore at https://chrome.google.com/webstore/detail/webcat/goapolmdanikiifibfibnnipepmdalkd
